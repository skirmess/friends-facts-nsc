
FriendsFacts NSC (no Sea Cosmos)

This add-on is based on version 1.1 of FriendsFacts from AnduinLothar
which did not use Sea nor Cosmos. It is updated to work with WoW 2.0.
This is for all the people who would like to use FriendsFacts without
the huge Sea/Cosmos overhead.

All Credit belongs to AnduinLothar.

Remember friends level, class, location and the last time you've seen
them online after they've logged off and show then in your friend
list.

*** Changelog

Version 9
Updated TOC for WoW 3.1.2

Version 8
Replaced a call to GetWidth() with GetStringWidth() to fix the display bug
where the text was messed up for long zone names

Version 7
Updated TOC for WoW 3.0.2

Version 6
Fix for WoW 2.4.3 (nameLocationText was changed into LocationText and nameText)

Version 5
Updated TOC for WoW 2.4.0
We show the last time you've seen a friend in the same way as it's shown
in the guild tab. We no longer show the date you've seen a friend the
last time.

Version 4
Updated TOC for WoW 2.3.0

Version 3
Updated TOC for WoW 2.0.3
Instead of wrappiung the original function, we use the new hooksecurefunc().

Version 2 (based on FriendsFacts v1.1 from AnduinLothar)
Replaced the RegisterForSave() with an entry in the toc file.
Additionaly, report the time you've seen the user online last.
The look is more identical with the default WoW look.
Made Friend List Realm Specific (Warning! All old friend data will be
lost). (inspired by FriendShare 1.2)


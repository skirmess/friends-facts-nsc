
Friends Facts NSC (no Sea Cosmos)

Remember friends level and class and the last time you've seen them online
after they've logged off and show then in your friends list.

*** Changelog

Version 19
 * Updated for WoW 6.0.0

Version 18
 * Updated for WoW 5.2.0

Version 17
 * Fixed a display bug after removing a note on a RealId friend

Version 16
 * Updated for MoP

Version 15
 * Fixed null pointer exception for friends playing Diablo III

Version 14
 * Updated for WoW 4.3.0

Version 13
 * Updated for WoW 4.0.1

Version 12
 * Show the Note in the friends list. Don't know why Blizzard removed that.
 * EventHandler() is now local

Version 11
 * new implementation to support the completely changed 3.3.5 friends list

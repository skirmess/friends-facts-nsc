
FriendsFacts NSC (no Sea Cosmos) 2

This add-on is based on version 1.1 of FriendsFacts from AnduinLothar
which did not use Sea nor Cosmos. It is updated to work with WoW 2.0.
This is for all the people who would like to use FriendsFacts without
the huge Sea/Cosmos overhead.

All Credit belongs to AnduinLothar.

Remember friends level, class, location and the last time you've seen
them online after they've logged off and show then in your friend
list.

*** Changelog

Version 4
Updated TOC for WoW 2.3.0

Version 3
Updated TOC for WoW 2.0.3
Instead of wrappiung the original function, we use the new hooksecurefunc().

Version 2 (based on FriendsFacts v1.1 from AnduinLothar)
Replaced the RegisterForSave() with an entry in the toc file.
Additionaly, report the time you've seen the user online last.
The look is more identical with the default WoW look.
Made Friend List Realm Specific (Warning! All old friend data will be
lost). (inspired by FriendShare 1.2)

